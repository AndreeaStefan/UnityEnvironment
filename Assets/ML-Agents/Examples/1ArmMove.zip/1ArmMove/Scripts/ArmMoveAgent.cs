﻿using System.Collections;
using System.Collections.Generic;
using MLAgents;
using UnityEngine;

public class ArmMoveAgent  : Agent
{

    private ArmMoveAcademy _academy;
    private const int MAX_TARGETS = 3;
    private int _numberOfTargetsTouched = 0;

    public GameObject Ground;
    public GameObject Area;
    public GameObject LeftArm;
    public GameObject RightArm;
    public List<Target> Targets;

     Rigidbody _agentRb; 
     RayPerception _rayPer;
     Renderer _groundRenderer;
     Bounds _areaBounds;
     Material _groundMaterial;
     WallContact _detectWall;


    void Awake()
    {
        _academy = FindObjectOfType<ArmMoveAcademy>(); 
    }


    public override void InitializeAgent()
    {
        base.InitializeAgent();
        _rayPer = GetComponent<RayPerception>();
        _agentRb = GetComponent<Rigidbody>();

        _areaBounds = Ground.GetComponent<Collider>().bounds;
        _groundRenderer = Ground.GetComponent<Renderer>();
        _groundMaterial = _groundRenderer.material;

        _detectWall = GetComponent<WallContact>();
        _detectWall.agent = this;
        /*
        if (LeftArm != null)
        {
            var component = LeftArm.GetComponent<TargetContact1>();
            component.agent = this;
        }

        if (RightArm != null)
        {
            var component = RightArm.GetComponent<TargetContact1>();
            component.agent = this;
        }
        */
    }

    public override void CollectObservations()
    {
       
        var rayDistance = 10f;
        float[] rayAngles = { 0f, 45f, 90f, 135f, 180f, 110f, 70f };
        var detectableObjects = new[] { "wall", "target" };
        AddVectorObs(_rayPer.Perceive(rayDistance, rayAngles, detectableObjects, 0f, 0f));
        foreach (var target in Targets)
        {
            AddVectorObs(target.isTriggered);
        }
        
    }

    public override void AgentAction(float[] vectorAction, string textAction)
    {
        // Move the agent using the action.
        MoveAgent(vectorAction);

        // Penalty given each step to encourage agent to finish task quickly.
        AddReward(-1f / agentParameters.maxStep);
    }

    /// <summary>
    /// Moves the agent according to the selected action.
    /// </summary>
    public void MoveAgent(float[] act)
    {

        Vector3 dirToGo = Vector3.zero;
        Vector3 rotateDir = Vector3.zero;

        int action = Mathf.FloorToInt(act[0]);

        // Goalies and Strikers have slightly different action spaces.
        switch (action)
        {
            case 1:
                dirToGo = transform.forward * 1f;
                break;
            case 2:
                dirToGo = transform.forward * -1f;
                break;
            case 3:
                rotateDir = transform.up * 1f;
                break;
            case 4:
                rotateDir = transform.up * -1f;
                break;
            case 5:
                dirToGo = transform.right * -0.75f;
                break;
            case 6:
                dirToGo = transform.right * 0.75f;
                break;
        }
        transform.Rotate(rotateDir, Time.fixedDeltaTime * 100f);
       
        _agentRb.AddForce(dirToGo * _academy.agentRunSpeed, ForceMode.VelocityChange);
      //  _agentRb.MovePosition(transform.position + dirToGo * _academy.agentRunSpeed * Time.deltaTime);
    }

    public void MoveAgent2(float[] act)
    {
        var x = Mathf.Clamp(act[0], -1, 1);
        var r = Mathf.Clamp(act[1], -1, 1);
        var rotationDirection = r >= 0 ? 1 : -1;
        var movingDirection = x >= 0 ? 1 : -1;

        transform.Rotate(transform.up * rotationDirection, Time.fixedDeltaTime * 2000f * r);
        _agentRb.AddForce(transform.forward * x * movingDirection * _academy.agentRunSpeed, ForceMode.VelocityChange);
    }

    public override void AgentReset()
    {
       
        transform.position = GetRandomSpawnPosition();
        _agentRb.velocity = Vector3.zero;
        _agentRb.angularVelocity = Vector3.zero;
        _numberOfTargetsTouched = 0;
        foreach (var target in Targets)
        {
            target.isTriggered = false;
            target.ResetTransform();
        }
    }

    IEnumerator GoalScoredSwapGroundMaterial(Material mat, float time)
    {
        _groundRenderer.material = mat;
        yield return new WaitForSeconds(time); // Wait for 2 sec
        _groundRenderer.material = _groundMaterial;
    }

    private Vector3 GetRandomSpawnPosition()
    {
        var foundNewSpawnLocation = false;
        var randomSpawnPos = Vector3.zero;
        while (foundNewSpawnLocation == false)
        {
            var randomPosX = Random.Range(-_areaBounds.extents.x * _academy.spawnAreaMarginMultiplier,
                _areaBounds.extents.x * _academy.spawnAreaMarginMultiplier);

            var randomPosZ = Random.Range(-_areaBounds.extents.z * _academy.spawnAreaMarginMultiplier,
                _areaBounds.extents.z * _academy.spawnAreaMarginMultiplier);

            randomSpawnPos = Ground.transform.position + new Vector3(randomPosX, 1f, randomPosZ);

            // Checks if not colliding with anything
            if (Physics.CheckBox(randomSpawnPos, new Vector3(1f, 0.01f, 1f)) == false)
            {
                foundNewSpawnLocation = true;
            }
        }
        return randomSpawnPos;
    }

    public void IsTarget()
    {
        
        AddReward(5);
        _numberOfTargetsTouched += 1;
        StartCoroutine(GoalScoredSwapGroundMaterial(_academy.successMaterial, 0.5f));
        if (_numberOfTargetsTouched >= MAX_TARGETS)
        {
            Done();
        }
    }

    public void IsWall()
    {
          AddReward(-0.5f);
    }


}
